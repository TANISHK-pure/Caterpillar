#!/usr/bin/env python3
"""truck_orchestrator.py — Cat Tech Challenge 2026 · Team TTSK12
Bridges Gazebo trucks to the MATLAB NFP+MILP brain.
"""
import math
import os
import subprocess
import tempfile
import time
from enum import Enum, auto

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Point, Pose, PoseArray, Twist
from nav_msgs.msg import Odometry
from std_msgs.msg import Float64MultiArray, Int32

PADDOCK_GATE = (0.0, 0.0)
EXIT_AREA    = (50.0, 110.0)
PAD_ENTRY    = (50.0, 60.0)
QUEUE_PADS   = {1: (-30.0, -50.0), 2: (-30.0, -75.0), 3: (-30.0, -100.0)}

# (truck_id, class_id, pad_index)
FLEET = [(1, 1, 1), (2, 2, 2), (3, 3, 3)]


class State(Enum):
    QUEUED = auto()
    ANNOUNCED = auto()
    AWAITING_GRANT = auto()
    DRIVING_IN = auto()
    DUMPING = auto()
    DRIVING_OUT = auto()
    DONE = auto()


class TruckState:
    def __init__(self, tid, cls):
        self.id = tid; self.cls = cls
        self.x = 0.0; self.y = 0.0; self.yaw = 0.0
        self.target_x = None; self.target_y = None; self.target_r = None
        self.grant_time = None; self.state = State.QUEUED
        self.locked = False; self.dump_start = None
        self.waypoints = []; self.wp_idx = 0


class TruckOrchestrator(Node):
    def __init__(self):
        super().__init__('truck_orchestrator')
        self.trucks = {tid: TruckState(tid, cls) for tid, cls, _ in FLEET}
        self.announce_idx = 0
        self.t0 = time.time()

        # --- publishers ---
        self.pub_arrival   = self.create_publisher(Float64MultiArray, '/truck_arrivals',  10)
        self.pub_confirm   = self.create_publisher(Point,             '/dump_confirm',    10)
        self.pub_done      = self.create_publisher(Int32,             '/truck_completed', 10)
        self.pub_positions = self.create_publisher(PoseArray,         '/truck_positions', 10)
        self.pub_cmd = {tid: self.create_publisher(Twist, f'/truck_{tid}/cmd_vel', 10)
                        for tid in self.trucks}

        # --- subscribers (from MATLAB) ---
        self.create_subscription(Float64MultiArray, '/dump_plans',          self.on_plan,   10)
        self.create_subscription(Float64MultiArray, '/entry_grants',  self.on_grants, 10)
        self.create_subscription(Int32,             '/milp_lock',           self.on_lock,   10)
        self.create_subscription(Float64MultiArray, '/bay_assignments', self.on_bay, 10)

        # --- subscribers (from Gazebo via bridge) ---
        for tid in self.trucks:
            self.create_subscription(
                Odometry, f'/truck_{tid}/odom',
                lambda msg, t=tid: self.on_odom(msg, t), 10)

        # --- timers ---
        self.create_timer(0.1, self.tick)
        self.create_timer(0.1, self.publish_positions)
        self.create_timer(8.0, self.announce_next)

        self.get_logger().info("orchestrator up — 3 trucks, announcing every 3s")

    # ===================== Callbacks =====================
    def on_plan(self, msg):
        d = list(msg.data)
        if len(d) != 5: return
        tid = int(d[0])
        t = self.trucks.get(tid)
        if t is None: return
        t.target_x = float(d[2]); t.target_y = float(d[3]); t.target_r = float(d[4])
        if t.state == State.ANNOUNCED:
            t.state = State.AWAITING_GRANT
        self.get_logger().info(
            f"plan T{tid} → ({t.target_x:.1f}, {t.target_y:.1f}) r={t.target_r}")

    def on_grants(self, msg):
        d = list(msg.data)
        for i in range(0, len(d), 2):
            tid = int(d[i]); gt = float(d[i+1])
            t = self.trucks.get(tid)
            if t is None: continue
            t.grant_time = gt
            # Grant received = cleared to enter. MILP decides who/when via
            # the order grants arrive; we don't sync absolute clocks across nodes.
            if t.state == State.AWAITING_GRANT:
                t.state = State.DRIVING_IN
                self.get_logger().info(f"grant T{tid} — driving in")

    def on_lock(self, msg):
        tid = int(msg.data)
        t = self.trucks.get(tid)
        if t is None: return
        t.locked = True
        self.get_logger().warn(f"!! LOCK T{tid} (MILP override)")

    def on_odom(self, msg, tid):
        t = self.trucks[tid]
        t.x = msg.pose.pose.position.x
        t.y = msg.pose.pose.position.y
        q = msg.pose.pose.orientation
        t.yaw = math.atan2(2*(q.w*q.z + q.x*q.y), 1 - 2*(q.y*q.y + q.z*q.z))

    # ===================== Main loop =====================
    def announce_next(self):
        if self.announce_idx >= len(FLEET): return
        tid, cls, _ = FLEET[self.announce_idx]
        t = self.trucks[tid]
        if t.state != State.QUEUED: return
        msg = Float64MultiArray(); msg.data = [float(tid), float(cls)]
        self.pub_arrival.publish(msg)
        t.state = State.ANNOUNCED
        self.get_logger().info(f"announced T{tid} (class {cls})")
        self.announce_idx += 1

    def publish_positions(self):
        msg = PoseArray()
        msg.header.frame_id = 'world'
        msg.header.stamp = self.get_clock().now().to_msg()
        max_id = max(self.trucks.keys()) if self.trucks else 0
        for tid in range(1, max_id + 1):
            p = Pose()
            t = self.trucks.get(tid)
            if t is not None:
                p.position.x = t.x; p.position.y = t.y
            msg.poses.append(p)
        self.pub_positions.publish(msg)

    def tick(self):
        for t in self.trucks.values():
            if t.locked:
                self.stop(t); continue
            if t.state == State.DRIVING_IN:
                # Build waypoint route once (placeholder for Hybrid A*)
                if not t.waypoints:
                    t.waypoints = [
                        (0.0, 5.0),      # gate centerline
                        (0.0, 40.0),     # past south corridor wall
                        (25.0, 75.0),    # between chicane berms
                        (50.0, 115.0),   # north wall pad-entry gap
                        (t.target_x, t.target_y),  # final NFP dump coordinate
                    ]
                    t.wp_idx = 0
                gx, gy = t.waypoints[t.wp_idx]
                is_final = (t.wp_idx == len(t.waypoints) - 1)
                tol = 2.5 if is_final else 6.0
                self.drive_toward(t, gx, gy)
                if self.reached(t, gx, gy, tol=tol):
                    if is_final:
                        self.stop(t)
                        t.state = State.DUMPING
                        t.dump_start = time.time()
                        self.get_logger().info(f"T{t.id} dumping at ({t.x:.1f},{t.y:.1f})")
                    else:
                        t.wp_idx += 1
                        self.get_logger().info(f"T{t.id} waypoint {t.wp_idx}/{len(t.waypoints)-1}")
            elif t.state == State.DUMPING:
                if time.time() - t.dump_start > 4.0:
                    self.spawn_pile(t)
                    p = Point(); p.x = t.x; p.y = t.y
                    self.pub_confirm.publish(p)
                    t.state = State.DRIVING_OUT
                    self.get_logger().info(f"T{t.id} dump complete — returning")
            elif t.state == State.DRIVING_OUT:
                self.drive_toward(t, EXIT_AREA[0], EXIT_AREA[1])
                if self.reached(t, EXIT_AREA[0], EXIT_AREA[1], tol=5.0):
                    self.stop(t)
                    t.state = State.DONE
                    m = Int32(); m.data = t.id
                    self.pub_done.publish(m)
                    self.get_logger().info(f"T{t.id} DONE")

    # ===================== Drive helpers =====================
    def drive_toward(self, t, gx, gy):
        dx = gx - t.x; dy = gy - t.y
        dist = math.hypot(dx, dy)
        target_yaw = math.atan2(dy, dx)
        yaw_err = self.angle_wrap(target_yaw - t.yaw)
        tw = Twist()
        if abs(yaw_err) > 0.25:
            tw.angular.z = 0.6 * (1.0 if yaw_err > 0 else -1.0)
        else:
            tw.linear.x = min(4.0, dist * 0.4)
            tw.angular.z = 1.2 * yaw_err
        self.pub_cmd[t.id].publish(tw)

    def reached(self, t, gx, gy, tol):
        return math.hypot(gx - t.x, gy - t.y) < tol

    def stop(self, t):
        self.pub_cmd[t.id].publish(Twist())

    @staticmethod
    def angle_wrap(a):
        return (a + math.pi) % (2 * math.pi) - math.pi

    # ===================== Pile spawning =====================
    def spawn_pile(self, t):
        radius = t.target_r if t.target_r else 3.0
        sdf = f'''<?xml version="1.0"?>
<sdf version="1.10">
  <model name="pile_t{t.id}">
    <static>true</static>
    <pose>{t.x} {t.y} 0.5 0 0 0</pose>
    <link name="link">
      <visual name="v">
        <geometry><cylinder><radius>{radius}</radius><length>1.5</length></cylinder></geometry>
        <material><ambient>0.45 0.32 0.20 1</ambient><diffuse>0.65 0.48 0.30 1</diffuse></material>
      </visual>
      <collision name="c">
        <geometry><cylinder><radius>{radius}</radius><length>1.5</length></cylinder></geometry>
      </collision>
    </link>
  </model>
</sdf>'''
        with tempfile.NamedTemporaryFile('w', suffix='.sdf', delete=False) as f:
            f.write(sdf); tmp = f.name
        cmd = ['gz', 'service', '-s', '/world/cat_paddock/create',
               '--reqtype', 'gz.msgs.EntityFactory',
               '--reptype', 'gz.msgs.Boolean',
               '--timeout', '2000',
               '--req', f'sdf_filename: "{tmp}", name: "pile_t{t.id}"']
        try:
            subprocess.run(cmd, check=True, capture_output=True, timeout=3)
        except Exception as e:
            self.get_logger().warn(f"pile spawn failed: {e}")


    def on_bay(self, msg):
        d = list(msg.data)
        if len(d) >= 2:
            self.get_logger().info(f"bay assignment: T{int(d[0])} → bay {int(d[1])}")


def main():
    rclpy.init()
    node = TruckOrchestrator()
    try: rclpy.spin(node)
    except KeyboardInterrupt: pass
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
